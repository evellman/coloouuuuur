public class ShepardFairey2
{
    public static void main(String[] args)
    {
        Picture pic = new Picture("images/slefer.jpg");

        Pixel[] pixels;
        pixels = pic.getPixels();
        
        int r = 0, g = 0, b = 0, value = 0, small = 0, big = 0, range = 0;
        
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            value = (r + g + b)/3;
        
            //method two
            if (value < small)
            {
                small = value;
            }
            if (value > big)
            {
                big = value;
            }
            
            range = big - small;
            if (value <= (range/4))
            {
                spot.setRed(0);
                spot.setGreen(51);
                spot.setBlue(76);
            }
            else if (value <= 2*(range/4))
            {
                spot.setRed(217);
                spot.setGreen(26);
                spot.setBlue(33);
            }
            else if (value <= 3*(range/4))
            {
                spot.setRed(112);
                spot.setGreen(150);
                spot.setBlue(158);
            }
            else
            {
                spot.setRed(252);
                spot.setGreen(227);
                spot.setBlue(166);
            }
        }
        
        pic.explore();
        
        pic.write("images/slefer2.jpg");
    }
}