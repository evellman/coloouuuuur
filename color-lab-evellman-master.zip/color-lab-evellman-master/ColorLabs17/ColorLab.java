import java.awt.*;
import java.util.*;
import java.util.List;

public class ColorLab
{
    public static void main(String[] args)
    {
        Picture pic1 = new Picture("images/swan.jpg");
        Picture pic2 = new Picture("images/swan.jpg");
        Picture pic3 = new Picture("images/swan.jpg");
        Picture pic4 = new Picture("images/swan.jpg");
        Picture pic5 = new Picture("images/swan.jpg");
        Picture pic6 = new Picture("images/swan.jpg");
        Picture pic7 = new Picture("images/swan.jpg");
        Picture pic8 = new Picture("images/swan.jpg");
        
        pic1.explore();
        
        Pixel[] pixels;
        pixels = pic1.getPixels();
        
        int r = 0, g = 0, b = 0;
                
        //maxBlue()
        for (Pixel spot : pixels)
        {
            spot.setBlue(255);
        }
        pic1.explore();
        
        //maxRed()
        for (Pixel spot : pixels)
        {
            spot.setRed(255);
        }
        
        //maxGreen()
        for (Pixel spot : pixels)
        {
            spot.setGreen(255);
        }
        
        
        pixels = pic2.getPixels();
        //negate()
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            r = 255 - r;
            g = 255 - g;
            b = 255 - b;
            
            spot.setRed(r);
            spot.setGreen(g);
            spot.setBlue(b);
        }
        pic2.explore();
        
        pixels = pic3.getPixels();
        final double FACTOR = 1.5;
        //adjustRed
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            
            spot.setRed((int)(r*FACTOR));
        }
        pic3.explore();
        
        //adjustGreen
        for (Pixel spot : pixels)
        {
            g = spot.getGreen();
            
            spot.setGreen((int)(g*FACTOR));
        }
        
        //adjustRed
        for (Pixel spot : pixels)
        {
            b = spot.getBlue();
            
            spot.setBlue((int)(b*FACTOR));
        }
        
        
        pixels = pic4.getPixels();
        int value = 0;
        //grayscale
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            value = (r + g + b)/3;
            
            spot.setRed(value);
            spot.setGreen(value);
            spot.setBlue(value);
        }
        pic4.explore();
        
        pixels = pic5.getPixels();
        //darken
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            r-=50;
            g-=50;
            b-=50;
            
            spot.setRed(r);
            spot.setGreen(g);
            spot.setBlue(b);
        }
        pic5.explore();
        
        //lighten
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            r+=50;
            g+=50;
            b+=50;
            
            spot.setRed(r);
            spot.setGreen(g);
            spot.setBlue(b);
        }
        
        pixels = pic6.getPixels();
        //colorify
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            if (r < 80 && g < 80 && b < 80)
            {
                spot.setRed((int)(r*1.9));
                spot.setGreen((int)(g*.8));
                spot.setBlue(0);
            }
        }
        pic6.explore();
        
        pixels = pic7.getPixels();
        //swap2
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            b = spot.getBlue();
            
            spot.setRed(b);
            spot.setBlue(r);
        }
        pic7.explore();
        
        pixels = pic8.getPixels();
        //swap3
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            spot.setRed(b);
            spot.setGreen(r);
            spot.setBlue(g);
        }
        pic8.explore();
    }
}