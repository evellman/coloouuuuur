import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.text.*;
import java.util.*;
import java.util.List; // resolves problem with java.awt.List and java.util.List

/**
 * A class that represents a picture.  This class inherits from
 * SimplePicture and allows the student to add functionality to
 * the Picture class.
 *
 * Copyright Georgia Institute of Technology 2004-2005
 * @author Barbara Ericson ericson@cc.gatech.edu
 */
public class Picture extends SimplePicture
{
  ///////////////////// constructors //////////////////////////////////

  /**
   * Constructor that takes no arguments
   */
  public Picture ()
  {
    /* not needed but use it to show students the implicit call to super()
     * child constructors always call a parent constructor
     */
    super();
  }

  /**
   * Constructor that takes a file name and creates the picture
   * @param fileName the name of the file to create the picture from
   */
  public Picture(String fileName)
  {
    // let the parent class handle this fileName
    super(fileName);
  }

  /**
   * Constructor that takes the width and height
   * @param width the width of the desired picture
   * @param height the height of the desired picture
   */
  public Picture(int width, int height)
  {
    // let the parent class handle this width and height
    super(width,height);
  }

  /**
   * Constructor that takes a picture and creates a
   * copy of that picture
   */
  public Picture(Picture copyPicture)
  {
    // let the parent class do the copy
    super(copyPicture);
  }

  /**
   * Constructor that takes a buffered image
   * @param image the buffered image to use
   */
  public Picture(BufferedImage image)
  {
    super(image);
  }

  ////////////////////// methods ///////////////////////////////////////

  /**
   * Method to return a string with information about this picture.
   * @return a string with information about the picture such as fileName,
   * height and width.
   */
  public String toString()
  {
    String output = "Picture, filename " + getFileName() +
      " height " + getHeight()
      + " width " + getWidth();
    return output;

  }

  /*
   * makes the image gray
   */
  public void gray()
  {
      Pixel[] pixelArray = this.getPixels();        //this is not the best way for a large pic...too many items in an array
      Pixel pixel = null;
      int intensity = 0;

      for (int i = 0; i < pixelArray.length; i++)
      {
          pixel = pixelArray[i];

          intensity = (int) ((pixel.getRed() + pixel.getGreen() + pixel.getBlue())/3);

          pixel.setColor(new Color(intensity,intensity,intensity));
      } //end of loop
  }//end of gray
  
  public void redify()
  {
      Pixel[] pixelArray = this.getPixels();        //this is not the best way for a large pic...too many items in an array
      Pixel pixel = null;
      
      for (int i = 0; i < pixelArray.length; i++)
      {
          pixel = pixelArray[i];
          pixel.setRed(240);
      } //end of loop
    }

  public void negative()
  {
      Pixel pixel = null;
      
      //goes thru columns
      for (int x = 0; x < getWidth() ; x++) 
      {
          //goes thru rows 
          //puts smaller pic in lower left corner of original
          for (int y = 0; y < getHeight(); y++) 
          {
              pixel = getPixel(x,y); //grabs the pixel
              pixel.setColor(new Color(255-pixel.getRed(),255-pixel.getGreen(),255-pixel.getBlue())); //changes the color
            }//end of rows

        }//end of columns
    }  
    
  public void posterize()
  {
      
      Pixel[] pixelArray = this.getPixels();        //this is not the best way for a large pic...too many items in an array
      Pixel pixel = null;
      
      for (int i = 0; i < pixelArray.length; i++)
      {
          pixel = pixelArray[i];

          if (pixel.getRed() < 10)
          {
              pixel.setColor(new Color(5,10,0));        //black
            }
          else if (pixel.getRed() < 80)
          {
              pixel.setColor(new Color(80,115,20));     //dark green
            }
          else if (pixel.getRed() < 100)
          {
              pixel.setColor(new Color(115,105,105));   //gray
            }
          else if (pixel.getRed() < 185)
          {
              if (pixel.getGreen() < 140)
                pixel.setColor(new Color(175,130,50));  //brown
              else 
                pixel.setColor(new Color(175,190,20));  //green
            }
          else
            pixel.setColor(new Color(230,230,200));     //white
        }
    }

  /*
   * copies KatieFancy to a new image
   */
  public void copyKate(/*source file*/)
  {
    String sourceFile = ("images/KatieFancy.jpg");
    Picture sourcePicture = new Picture(sourceFile);

    //if source > target, you can get an error
    Pixel sourcePixel = null;
    Pixel targetPixel = null;

    for (int sourceX = 0, targetX = 100; sourceX < sourcePicture.getWidth();sourceX++, targetX++) //goes thru columns
    {
        for (int sourceY = 0, targetY = 100; sourceY < sourcePicture.getHeight();sourceY++, targetY++) //goes thru rows
        {
            sourcePixel = sourcePicture.getPixel(sourceX,sourceY);  //grabs the source pixel
            targetPixel = this.getPixel(targetX,targetY); //grabs the target pixel
            targetPixel.setColor(sourcePixel.getColor()); //makes the target the same color as the source
        }//end of rows

    }//end of columns

  }//end of copyKate

  /*
   * copies an image to another image
   */
  public void copyImage(Picture sourcePicture, int x, int y)
  {
    //if source > target, you can get an error
    Pixel sourcePixel = null;
    Pixel targetPixel = null;

    for (int sourceX = 0, targetX = x; sourceX < sourcePicture.getWidth();sourceX++, targetX++) //goes thru columns
    {
        for (int sourceY = 0, targetY = y; sourceY < sourcePicture.getHeight();sourceY++, targetY++) //goes thru rows
        {
            sourcePixel = sourcePicture.getPixel(sourceX,sourceY);  //grabs the source pixel
            targetPixel = this.getPixel(targetX,targetY); //grabs the target pixel
            targetPixel.setColor(sourcePixel.getColor()); //makes the target the same color as the source
        }//end of rows

    }//end of columns

  }//end of copyImage
    
  
  /*
   * Method to mirror around a vertical line in the middle
   * of the picture based on the width (right side to left side)
   */
  public void mirrorVertical()
  {
      int width = this.getWidth();
      int mirrorPoint = width/2;
      
      Pixel leftPixel = null;
      Pixel rightPixel = null;
      
      //loop thru rows
      for (int y = 0; y < getHeight(); y++)
      {
          
          //loop thru columns (0 - mirrorpoint)
          for (int x = 0; x < mirrorPoint; x++)
          {
            leftPixel = getPixel(x,y);  
            rightPixel = getPixel(width -x -1,y);
            leftPixel.setColor(rightPixel.getColor());
            }//end of columns
            
        }//end of rows
        
    }//end of mirror vert
    
  public void flipVertical()
  {

      Pixel leftPixel = null;
      Pixel rightPixel = null;
      Color tempColor = null;
      
      //loop thru rows
      for (int y = 0; y < getHeight(); y++)
      {
          
          //loop thru columns 
          for (int x = 0; x < getWidth()/2; x++)
          {
            leftPixel = getPixel(x,y);  
            rightPixel = getPixel(getWidth() -x -1,y);
            tempColor = leftPixel.getColor();


            leftPixel.setColor(rightPixel.getColor());
            rightPixel.setColor(tempColor);
            
            }//end of columns
            
        }//end of rows
    }//end of flipVert
    
  /*
   * method to mirror around a horizontal line in the middle 
   * of the picture based on the height
   */  
  public void mirrorHorizontal()
  {
      int height = this.getHeight();
      int mirrorPoint = height/2;
      
      Pixel leftPixel = null;
      Pixel rightPixel = null;
      
      //loop thru columns (0 - mirror point)
      for (int y = 0; y < mirrorPoint; y++)
      {
          
          //loop thru rows 
          for (int x = 0; x < getWidth(); x++)
          {
            leftPixel = getPixel(x,y);  
            rightPixel = getPixel(x,height - 1-y);
            rightPixel.setColor(leftPixel.getColor());
            }//end of columns
            
        }//end of rows
        
    }//end of mirror horizontal
    
  /*
   * method to mirror around a horizontal line and a vertical line 
   * in the middle of the picture based on height and width
   */
    public void mirrorBoth()
  {

      mirrorVertical();
      mirrorHorizontal();
    }//end of mirrorBoth
    
    public void scaleSmaller(int tY, int sY, int width)
  {

      //if source > target, you can get an error
      Pixel sourcePixel = null;
      Pixel targetPixel = null;

      //goes thru columns
      for (int sourceX = 0, targetX = 0; sourceX < width;sourceX+=2, targetX++) 
      {
          //goes thru rows 
          //puts smaller pic in lower left corner of original
          for (int sourceY = sY, targetY = tY; sourceY < this.getHeight(); sourceY+=2, targetY++) 
          {
              sourcePixel = getPixel(sourceX,sourceY);  //grabs the source pixel
              targetPixel = getPixel(targetX,targetY); //grabs the target pixel
              targetPixel.setColor(sourcePixel.getColor()); //makes the target the same color as the source
            }//end of rows

        }//end of columns

      
    
    }  
    
  public void recursiveSmaller(int newTargetY, int newSourceY, int width, int height)
  {
      if (height > 30)
      {
          scaleSmaller(newTargetY,newSourceY,width);
          recursiveSmaller(newTargetY+(height/4),newTargetY,width/2,height/2);
        }
    }
    
  public static void main(String[] args)
  {
     String fileName = FileChooser.pickAFile();
     Picture pictObj = new Picture(fileName);
     pictObj.explore();
  }

} // this } is the end of class Picture, put all new methods before this
