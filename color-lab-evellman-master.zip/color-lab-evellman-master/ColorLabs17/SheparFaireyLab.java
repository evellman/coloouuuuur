import java.awt.*;
import java.util.*;
import java.util.List;

public class SheparFaireyLab
{
    public static void main(String[] args)
    {
        Picture pic = new Picture("images/slefer.jpg");

        
        Pixel[] pixels;
        pixels = pic.getPixels();
        int value = 0,r = 0,g = 0,b = 0;
        int cutoff1 = 0,cutoff2 = 0,cutoff3 = 0;
        
        //grayscale
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            value = (r + g + b)/3;
            
            //method one
           
            cutoff1 = 255 / 4;
            cutoff2 = cutoff1 * 2;
            cutoff3 = cutoff2 + cutoff1;
            
            if (value <= cutoff1)
            {
                spot.setRed(0);
                spot.setGreen(51);
                spot.setBlue(76);
            }
            else if (value <= cutoff2)
            {
                spot.setRed(217);
                spot.setGreen(26);
                spot.setBlue(33);
            }
            else if (value <= cutoff3)
            {
                spot.setRed(112);
                spot.setGreen(150);
                spot.setBlue(158);
            }
            else
            {
                spot.setRed(252);
                spot.setGreen(227);
                spot.setBlue(166);
            }
            
        }
        pic.explore();
        
        pic.write("images/slefer1.jpg");
    }
}