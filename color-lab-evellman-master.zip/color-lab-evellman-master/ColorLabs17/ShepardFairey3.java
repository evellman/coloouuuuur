public class ShepardFairey3
{
    public static void main(String[] args)
    {
        Picture pic = new Picture("images/slefer.jpg");
        
        Pixel[] pixels;
        pixels = pic.getPixels();
        int value = 0,r = 0,g = 0,b = 0;
        int small = 0,big = 0,range = 0;
        
        for (Pixel spot : pixels)
        {
            r = spot.getRed();
            g = spot.getGreen();
            b = spot.getBlue();
            
            value = (r + g + b)/3;
            
            //method two
            if (value < small)
            {
                small = value;
            }
            if (value > big)
            {
                big = value;
            }
            
            range = big - small;

            if (value <= 1.5*(range/4)) //dark green
            {
                spot.setRed(39);
                spot.setGreen(110);
                spot.setBlue(0);
            }
            else if (value <= 2.25*(range/4))  //blue
            {
                spot.setRed(98);
                spot.setGreen(154);
                spot.setBlue(180);
            }
            else if (value <= 3*(range/4))  //green
            {
                spot.setRed(93);
                spot.setGreen(183);
                spot.setBlue(19);
            }
            else        //off-white
            {
                spot.setRed(242);
                spot.setGreen(233);
                spot.setBlue(103);
            }
        }
        
        pic.explore();
        
        pic.write("images/slefer3.jpg");
    }
}