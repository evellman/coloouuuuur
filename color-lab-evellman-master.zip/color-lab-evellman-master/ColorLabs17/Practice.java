import java.awt.*;
import java.util.*;
import java.util.List;

public class Practice
{
    public static void main (String[] args)
    {
        int value=0;
        
        Picture selfie = new Picture("images/APCSselfie.jpg");
        selfie.explore();
        
        Pixel[] pixels;
        pixels = selfie.getPixels();
        
        for (Pixel spot : pixels)
        {
            value = spot.getGreen();
            value = value * 2;
            
            spot.setGreen(value);
            
            if (spot.getX()+spot.getY() % 5 == 0)
            {
                spot.setColor(Color.red);
            }
        }
        
        selfie.explore();
    }
}
