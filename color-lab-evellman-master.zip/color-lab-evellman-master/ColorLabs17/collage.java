//width = 637
//height = 418

public class collage
{
    public static void main(String[] args)
    {
        Picture myPic1 = new Picture ("images/corgi10.jpg");
        Picture myPic2 = new Picture ("images/corgi10.jpg");
        Picture myPic3 = new Picture ("images/corgi10.jpg");
        Picture myPic4 = new Picture ("images/corgi10.jpg");
        Picture myPic5 = new Picture ("images/corgi10.jpg");
        Picture myPic6 = new Picture ("images/corgi10.jpg");
        
        Picture myCanvas = new Picture ("images/largecanvas.jpg");
        
        //image is negative
        myPic2.negative();
        
        //image gets recursively smaller
        myPic3.recursiveSmaller(myPic3.getHeight()/2,0,
                                myPic3.getWidth(),myPic3.getHeight());
                 
        //image is mirrored vertically and horizontally
        myPic4.mirrorBoth();
        
        //image is posterized
        myPic5.posterize();

        //image is facing the other direction 
        myPic6.flipVertical();
        
        //image is made more red
        myPic6.redify();
    
        myCanvas.copyImage(myPic1,0,0);
        myCanvas.copyImage(myPic2,637,0);
        myCanvas.copyImage(myPic6,0,418);
        myCanvas.copyImage(myPic4,637,418);
        myCanvas.copyImage(myPic3,0,836);
        myCanvas.copyImage(myPic5,637,836);
        
        myCanvas.explore(); 
        myCanvas.write("images/myCollage.jpg");
    }
}